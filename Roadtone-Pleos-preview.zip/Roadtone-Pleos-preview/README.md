# Roadtone Pleos 화면 검증 프로젝트

기존 로드톤 HTML 데모를 Android WebView에서 열어, Pleos 앱 창의 크기와 입력을 비교하기 위한 프로젝트입니다. 차량 SDK를 연결하는 개발은 이 검증 다음 단계입니다.

## 실행

1. Android Studio에서 이 폴더를 열고 Android SDK Platform 35를 준비합니다. Gradle 8.9와 JDK 17을 사용합니다.
2. [Pleos Connect Emulator 설치 안내](https://document.pleos.ai/en/docs/connect/guide/getting-started/application-development/setup-connect-sdk-emulator)에 따라 Mac용 ARM64 시스템 이미지를 추가하고 Pleos AVD를 실행합니다.
3. Android Studio에서 `app`을 실행합니다. 명령줄에서는 Gradle 설치 후 `gradle :app:assembleDebug`로 `app/build/outputs/apk/debug/app-debug.apk`를 빌드할 수 있습니다.

## Pleos 검증 순서

| 확인할 것 | 기대 동작 |
| --- | --- |
| 큰 앱 창과 축소 앱 창 | 음악 화면, 자연음 탭, 하단 재생 버튼이 앱 창 안에 남습니다. 음악 목록 안만 세로 스크롤됩니다. |
| 자연의 소리 | 탭을 한 번 누르면 네 가지 소리가 보이며, 하나를 고르면 실제 데모 음원이 재생됩니다. |
| 해안가 주차 → 콘솔 | EQ와 무드등을 조절하고, 직접 고른 조명은 다른 장면으로 넘어가도 유지됩니다. |
| 문 열기·닫기 | 화면의 도어 시뮬레이터에서 열면 앱 음량이 낮아지고 닫으면 복구됩니다. |
| 실제 차량 이벤트 | Vehicle SDK와 주행 제한·오디오 포커스 연동을 추가한 뒤 Pleos Virtual Console로 검증합니다. |

현재 상태는 Android 프로젝트 준비까지입니다. 이 환경에는 Android SDK와 Pleos AVD가 없어 APK 빌드와 Pleos 구동은 확인하지 못했습니다.
