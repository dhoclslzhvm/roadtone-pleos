package com.roadtone.preview;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;

public final class MainActivity extends Activity {
    private static final String APP_URL = "https://roadtone-preview.invalid/";
    private static final int PICK_AUDIO = 201;

    private WebView web;
    private ValueCallback<Uri[]> pendingFile;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBlockNetworkLoads(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (APP_URL.equals(request.getUrl().toString())) {
                    try {
                        return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                    } catch (IOException ignored) {
                        return null;
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !APP_URL.equals(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                finishFile(null);
                pendingFile = callback;
                Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("audio/*");
                try {
                    startActivityForResult(picker, PICK_AUDIO);
                } catch (ActivityNotFoundException ignored) {
                    finishFile(null);
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(APP_URL);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_AUDIO) {
            finishFile(WebChromeClient.FileChooserParams.parseResult(result, data));
        }
    }

    private void finishFile(Uri[] files) {
        if (pendingFile == null) return;
        ValueCallback<Uri[]> callback = pendingFile;
        pendingFile = null;
        callback.onReceiveValue(files);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("if (typeof audio !== 'undefined') audio.pause()", null);
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        finishFile(null);
        web.destroy();
        super.onDestroy();
    }
}
